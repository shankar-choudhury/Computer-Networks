#include "forwarding_table.hpp"

/**
 * Name: Shankar Choudhury
 * Case Network ID: sxc1782
 * Filename: forwarding_table.hpp
 * Date created: 2025-10-07
 * Brief description:
 *  This class carries the implementation of forwarding_table.hpp
 */